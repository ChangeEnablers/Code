var express = require("express");
var router = express.Router();

router.get("/", (req, res) => {
    res.render("homeback2backup.html");
    //   res.render("homeback2.html");
    // res.render("homeresponsive.html");
});

var GetTrendingProduct = require('../services/GetTrendingProduct');
router.get("/GetTrendingProduct", GetTrendingProduct.trending_product);

var GetDemandingProductData = require('../services/GetDemandingProductData');
router.get("/GetDemandingProductData", GetDemandingProductData.demanding_product);

var GetSeasonalProductData=require('../services/GetSeasonalProductData');
router.post("/GetSeasonalProductData",GetSeasonalProductData.seasonal_product);

var GetAssociation = require('../services/GetAssociation');
router.post("/GetAssociation", GetAssociation.association1);

// var getGraphData = require('../services/getGraphData');
// router.get("/getGraphData", getGraphData.GraphData);

// var getPrediction = require('../services/getPrediction');
// router.post("/getPrediction", getPrediction.Prediction);

// var uploadService = require('../services/uploadService');
// router.post("/upload", uploadService.upload);


module.exports = router;