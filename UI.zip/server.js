var path = require('path');
var express = require('express');

var app = express();

var staticPath = path.join(__dirname, '/');
app.use(express.static(staticPath));
app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, User-Agent,Content-Type, Accept, Authorization,Access-Control-Allow-Origin,Access-Control-Allow-Methods");
  res.header("Access-Control-Allow-Methods", "POST,GET,PUT");
  next();
});

app.listen(4000,'0.0.0.0', function () {
  console.log('listening');
});