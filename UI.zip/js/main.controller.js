var shopApp = angular.module('shopApp', []);
shopApp.controller('mainController', function ($scope, $http) {
     $scope.buypack=true;
    /*Get Trending*/
    $http.get("http://3.209.92.60:2209/change/gettrendingproducts").then(function (response) {
        $scope.gettrendingproducts=response.data.result;
                if ($scope.gettrendingproducts.length>1) {
                //console.log('(===============1============)',$scope.gettrendingproducts);    
                $scope.proLen=$scope.gettrendingproducts ;
                /*File*/
                for (var index = 0; index < $scope.gettrendingproducts.length; index++) {
                    var element = $scope.gettrendingproducts[index];
                    //console.log('Img element',element[0]);
                     if(element[3]) {  
                        var url =element[3];
                        //console.log('Image URL',url);
                        var request = new XMLHttpRequest();
                        request.open('HEAD', url, false);
                        request.send();
                        if(request.status == 200) {
                            $scope.pdfData = true;
                            $scope.imgFile =   $scope.gettrendingproducts.name+'.jpg';
                        } else {
                            if($scope.imgFile=='undefined.jpg'){
                            $scope.gettrendingproducts[index][3]="./slider/TrendingProduct/sorry.jpg";
                           // console.log('Image',$scope.imgFile,$scope.gettrendingproducts[index][3]);
                            }
                        
                            $scope.pdfData = false;
                        }
                    } else {
                        $scope.pdfData = false;
                    }
                    
                }
                             
                /*-------*/
                /*Get Seasonal Products*/
                var monthNames = ["January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"
                ];
                var d = new Date();
                console.log("The current month is " + monthNames[d.getMonth()]);
                $scope.month=monthNames[d.getMonth()];
                $http.get("http://3.209.92.60:2209/change/getseasonalproducts").then(function (response) {
                    $scope.getseasonalproducts= response.data.result[$scope.month];

                               for (var index = 0; index < $scope.getseasonalproducts.length; index++) {
                                            var element = $scope.getseasonalproducts[index];
                                            
                                            if(element[1][2]) {  
                                                var url =element[1][2];
                                                console.log('Image URL',url);
                                                var request = new XMLHttpRequest();
                                                request.open('HEAD', url, false);
                                                request.send();
                                                if(request.status == 200) {
                                                    $scope.pdfData = true;
                                                    $scope.imgFile =   $scope.getseasonalproducts.name+'.jpg';
                                                } else {
                                                    if($scope.imgFile=='undefined.jpg'){
                                                    $scope.getseasonalproducts[index][1][2]="./slider/TrendingProduct/sorry.jpg";
                                                    console.log('Image',$scope.imgFile,$scope.getseasonalproducts[index][1][2]);
                                                    }
                                                
                                                    $scope.pdfData = false;
                                                }
                                            } else {
                                                $scope.pdfData = false;
                                            }
                                        }


                        console.log('*******************',$scope.getseasonalproducts)
                        // console.log('(============2===============)',$scope.getseasonalproducts);
                        /*getdemandingproducts*/
                        $http.get("http://3.209.92.60:2209/change/getdemandingproducts").then(function (response) {
                        $scope.getdemandingproducts=response.data.result;
                        $scope.demLen=4;
                        $scope.getdemandcarousal=[];
                        for (var index = 0; index < $scope.demLen; index++) {
                            var element = $scope.getdemandingproducts[index];
                            $scope.getdemandcarousal.push(element);                                                        
                        }
                        for (var index = 0; index < $scope.getdemandingproducts.length; index++) {
                                var element = $scope.getdemandingproducts[index];   
                                console.log('------',element)                                             
                                if(element[3]) {  
                                    var url =element[3];
                                    console.log('Image URL',url);
                                    var request = new XMLHttpRequest();
                                    request.open('HEAD', url, false);
                                    request.send();
                                    if(request.status == 200) {
                                        $scope.pdfData = true;
                                        $scope.imgFile =   $scope.getdemandingproducts.name+'.jpg';
                                    } else {
                                        if($scope.imgFile=='undefined.jpg'){
                                        $scope.getdemandingproducts[index][3]="./slider/TrendingProduct/sorry.jpg";
                                        console.log('Image---------------',$scope.imgFile,$scope.getdemandingproducts[index][3]);
                                        }
                                    
                                        $scope.pdfData = false;
                                    }
                                } else {
                                    $scope.pdfData = false;
                                }
                           }
                        $scope.dem=true;
                        $scope.expandDemand=function(){
                            for (var index = 0; index < $scope.getdemandingproducts.length; index++) {
                                var element = $scope.getdemandingproducts[index];   
                                console.log('------',element)                                             
                                if(element[3]) {  
                                    var url =element[3];
                                    console.log('Image URL',url);
                                    var request = new XMLHttpRequest();
                                    request.open('HEAD', url, false);
                                    request.send();
                                    if(request.status == 200) {
                                        $scope.pdfData = true;
                                        $scope.imgFile =   $scope.getdemandingproducts.name+'.jpg';
                                    } else {
                                        if($scope.imgFile=='undefined.jpg'){
                                        $scope.getdemandingproducts[index][3]="./slider/TrendingProduct/sorry.jpg";
                                        console.log('Image---------------',$scope.imgFile,$scope.getdemandingproducts[index][3]);
                                        }
                                    
                                        $scope.pdfData = false;
                                    }
                                } else {
                                    $scope.pdfData = false;
                                }
                           }
                            $scope.dem=false;
                            $scope.demLen=$scope.getdemandingproducts.length;
                            $scope.getdemandcarousal=[];
                            for (var index = 0; index < $scope.demLen; index++) {
                                var element = $scope.getdemandingproducts[index];
                                $scope.getdemandcarousal.push(element);                                                        
                            }
                        }
                        $scope.expandDemandLess=function(){
                            $scope.dem=true;
                            $scope.demLen=4;
                            $scope.getdemandcarousal=[];
                            for (var index = 0; index < $scope.demLen; index++) {
                                var element = $scope.getdemandingproducts[index];
                                $scope.getdemandcarousal.push(element);                                                        
                            }
                        } 
                 

                        // console.log('(=============3==============)',$scope.getdemandingproducts);
                        /*Start Era*/
                            for (var index = 0; index < $scope.trend.length; index++) {
                                var element = $scope.trend[index];
                                element = "/slider/TrendingProduct/" + element + ".jpg"
                                $scope.trendImg.push(element)
                            }
                            $scope.trenddict = {};
                            $scope.newtrend = [];

                            function chunkArray(myArray, chunk_size) {
                                var index = 0;
                                $scope.proLen= myArray.length;
                                var arrayLength = myArray.length;
                                var tempArray = [];

                                for (index = 0; index < arrayLength; index += chunk_size) {
                                    myChunk = myArray.slice(index, index + chunk_size);
                                    // Do something if you want with the group
                                    tempArray.push(myChunk);
                                }

                                return tempArray;
                            }
                            var result = chunkArray($scope.gettrendingproducts, 8);
                            $scope.trend = result;
                            $scope.newtrend = [];
                            $scope.trenddict[0] = $scope.trend;
                            $scope.newtrendImg = [];
                            $scope.newtrendImg = chunkArray($scope.gettrendingproducts, $scope.proLen/4);
                            $scope.trenddict[0] = $scope.trend;
                            $scope.trenddict[1] = $scope.newtrendImg;
                            $scope.gettrendingproducts = $scope.gettrendingproducts;
                            $scope.gettrendingproducts = chunkArray($scope.gettrendingproducts, $scope.proLen/4);
                            $scope.gettrendingproducts=$scope.gettrendingproducts;
                            
                            for (var index = 0; index < $scope.proLen; index++) {
                                $scope.newtrend.push(index);
                            }
                            $scope.newtrend.splice(0,1);
                            $scope.getProInfo=function(name,price,qty,imgpath){
                                $scope.confirmModal=true;
                                $scope.proName=name;
                                $scope.price=price;
                                $scope.qty=qty;
                                $scope.imgPath=imgpath;
                                $scope.payload2={};
                                $scope.payload2['productName']=name;
                                console.log('Clicked index',index,'Info',  $scope.proName, $scope.qty,$scope.imgPath,$scope.payload2);
                                     $http.post("http://3.209.92.60:2209/change/getassociation1",$scope.payload2).then(function (response) {
                                        $scope.getassociationproducts=response.data.result;
                                        console.log("Association",$scope.getassociationproducts);
                                                   /*File*/
                                        for (var index = 0; index < $scope.getassociationproducts.length; index++) {
                                            var element = $scope.getassociationproducts[index];
                                            
                                            if(element[3]) {  
                                                var url =element[3];
                                                console.log('Image URL',url);
                                                var request = new XMLHttpRequest();
                                                request.open('HEAD', url, false);
                                                request.send();
                                                if(request.status == 200) {
                                                    $scope.pdfData = true;
                                                    $scope.imgFile =   $scope.getassociationproducts.name+'.jpg';
                                                } else {
                                                    if($scope.imgFile=='undefined.jpg'){
                                                    $scope.getassociationproducts[index][3]="./slider/TrendingProduct/sorry.jpg";
                                                    console.log('Image',$scope.imgFile,$scope.getassociationproducts[index][3]);
                                                    }
                                                
                                                    $scope.pdfData = false;
                                                }
                                            } else {
                                                $scope.pdfData = false;
                                            }
                                        }

                                });
                            }
                            $scope.confirmFun=function(){
                                $scope.confirmModal=false;
                            }

                            $scope.nameit="Recommendations"
                            $scope.getProInfoBack=function(name,qty,price,imgpath){
                                $scope.buypack=false;
                                $scope.proName=name;
                                $scope.price=price;
                                $scope.qty=qty;
                                $scope.imgPath=imgpath;
                                $scope.payload2['productName']=name;
                                console.log('Clicked index',index,'Info',  $scope.proName, $scope.qty,$scope.imgPath,$scope.payload2);
                                     $http.post("http://3.209.92.60:2209/change/getassociation1",$scope.payload2).then(function (response) {
                                        $scope.getassociationproducts=response.data.result;
                                        console.log("Association",$scope.getassociationproducts);
                                        if($scope.getassociationproducts.length>0){
                                            $scope.nameit="Recommendations";
                                                for (var index = 0; index < $scope.getassociationproducts.length; index++) {
                                                    var element = $scope.getassociationproducts[index];
                                                    
                                                    if(element[3]) {  
                                                        var url =element[3];
                                                        console.log('Image URL',url);
                                                        var request = new XMLHttpRequest();
                                                        request.open('HEAD', url, false);
                                                        request.send();
                                                        if(request.status == 200) {
                                                            $scope.pdfData = true;
                                                            $scope.imgFile =   $scope.getassociationproducts.name+'.jpg';
                                                        } else {
                                                            if($scope.imgFile=='undefined.jpg'){
                                                            $scope.getassociationproducts[index][3]="./slider/TrendingProduct/sorry.jpg";
                                                            console.log('Image',$scope.imgFile,$scope.getassociationproducts[index][3]);
                                                            }
                                                        
                                                            $scope.pdfData = false;
                                                        }
                                                    } else {
                                                        $scope.pdfData = false;
                                                    }
                                                }
 
                                        }
                                        else{
                                            $scope.nameit="" 
                                        }
                                     });

                            }
                            $scope.loginUser = function () {
                                // $scope.loginBtnShow = false 
                                // $scope.logoutBtnShow = true
                                // $scope.datadismiss = 'modal'
                                console.log('logged!', $scope.userid, $scope.password);
                                $scope.payload = {};
                                $scope.payload['username'] = $scope.userid;
                                $scope.payload['password'] = $scope.password;
                                console.log('payload', $scope.payload);
                                $scope.loginBtnShow = false
                                $scope.logoutBtnShow = true
                                $scope.loginError = "Login Success"
                                $http.post("http://3.209.92.60:2209/change/login", $scope.payload).then(function (response) {
                                
                                console.log('login responce', response.data);
                                if (response.data['result']=='Success') {
                                        $scope.datadismiss = "modal";
                                        $('#modal').modal('hide');
                                        console.log('Modal Response', $scope.datadismiss);

                                        $scope.loginBtnShow = false
                                        $scope.logoutBtnShow = true
                                        $scope.loginError = "Login Success"
                                        
                                        $http.get("http://3.209.92.60:2209/change/gettrendingproducts").then(function (response) {
                                            console.log('2nd Response',response);
                                        });
                                }
                                else{
                                    $scope.loginError = "Invalid Password / User ID"
                                }

                            });

                            }

                            $scope.logoutUser = function () {
                                console.log('Logged out');
                                $scope.logoutBtnShow = false
                                $scope.loginBtnShow = true

                            }

                        /*Close Era*/

                            
                        });
                      
                });
            }
        });

    $scope.appName = "Today's Trending"
    $scope.loginBtnShow = true
    $scope.confirmModal=true;
    $scope.trendImg = [];
    $scope.trend = [];
 
});
