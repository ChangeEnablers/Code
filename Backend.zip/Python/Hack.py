# -*- coding: utf-8 -*-
"""
Created on Fri Sep 28 16:29:07 2018

@author: dnathani
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Sep 18 19:25:56 2018

@author: dnathani
"""

from flask import request
import os
from flask import Flask
from flask import Response
import json
import pandas as pd
import psycopg2
from config import config 
import operator
from collections import OrderedDict
import itertools
#from mlxtend.preprocessing import TransactionEncoder
#from mlxtend.frequent_patterns import association_rules
#from mlxtend.frequent_patterns import apriori
from operator import itemgetter
from datetime import datetime 
from flask_cors import CORS

print("1")
df=pd.read_excel("KaggelData1.xlsx")
Description=df["Description"][0:100]
Quantity=df["Quantity"][0:100]
CustomerID=df['CustomerID'][0:100]
InvoiceNo=df['InvoiceNo'][0:100]
StockCode=df['StockCode'][0:100]
InvoiceDate=df['InvoiceDate'][0:100]
UnitPrice=df['UnitPrice'][0:100]
CustomerID=df['CustomerID'][0:100]
Country=df['Country'][0:100]


dic={}
for data in range(0,len(Description)):
    dic.update({Description[data]:[StockCode[data],UnitPrice[data]]})


print("2")
def connect():
    """ Connect to the PostgreSQL database server """
    conn = None
    try:
        # read connection parameters
        params = config()
 
        # connect to the PostgreSQL server
        print('Connecting to the PostgreSQL database...')
        conn = psycopg2.connect(**params)
        # create a cursor
        cur = conn.cursor()
        
# execute a statement
        print('PostgreSQL database version:')
        cur.execute('SELECT version()')
 
        # display the PostgreSQL database server version
        db_version = cur.fetchone()
        print(db_version)
      
    # close the communication with the PostgreSQL
        cur.close()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()
            print('Database connection closed.')
            
def create_tables():
    """ create tables in the PostgreSQL database"""
    command = (
        """
        CREATE TABLE ce_user (
            username VARCHAR(255) NOT NULL,
            password VARCHAR(255) NOT NULL
        )
        """)
    conn = None
    try:
        # read the connection parameters
        params = config()
        # connect to the PostgreSQL server
        conn = psycopg2.connect(**params)
        cur = conn.cursor()
        # create table one by one
        cur.execute(command)
        # close communication with the PostgreSQL database server
        cur.close()
        # commit the changes
        conn.commit()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()
            
def insert_vendor(username,password):
    """ insert a new vendor into the vendors table """
    sql = """INSERT INTO ce_user(username,password)
             VALUES(%s,%s);"""
    conn = None
    try:
        params = config()
        conn = psycopg2.connect(**params)
        cur = conn.cursor()
        cur.execute(sql, (username,password))
        conn.commit()
        cur.close()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()
            
def trending_product(CustomerID,Description,numberofproducts=10):
    UniquesDesc=list(set(Description))
    Price=[]
    CustomerCount=[]
    for data in UniquesDesc:
        df2=df[(df.Description==data)]
        Price.append(list(set(df2["UnitPrice"])))
        CustomerCount.append(len(list(set(df2['CustomerID']))))
    Result=[]
    for data1 in range(0,len(UniquesDesc)):
        dumy="./slider/TrendingProduct/" + str(UniquesDesc[data1]) + ".jpg"
        Result.append([UniquesDesc[data1],max(Price[data1]),CustomerCount[data1],dumy])
    print((sorted(Result, key=itemgetter(2),reverse=True) ))
    return sorted(Result, key=itemgetter(2),reverse=True)   
  
def demanding_product(Quantity,Description,numberofproducts=10):
    UniquesDesc=list(set(Description))
    Quantity1=[]
    Price1=[]
    for data3 in UniquesDesc:
        df1=df[(df.Description==data3)]     
        Quantity1.append(sum(df1["Quantity"].tolist()))
        Price1.append((list(set(df1["UnitPrice"]))))
    Result1=[]
    for data2 in range(0,len(UniquesDesc)):
        dumy="./slider/TrendingProduct/" + str(UniquesDesc[data2]) + ".jpg"
        Result1.append([UniquesDesc[data2],max(Price1[data2]),Quantity1[data2],dumy])
    print((sorted(Result1,key=itemgetter(2),reverse=True)))
    
    return sorted(Result1,key=itemgetter(2),reverse=True)  

def Seasonal():
#    uniQueCustId=set(CustomerID)
    MonthDict={1:"October",2:"February",3:"March",4:"April",5:"May",6:"June",7:"July",8:"August",9:"September",10:"October",11:"November",12:"October"}
    InvoiceTotal=[]
    totalProducts=[]
    Dict1={}
    Dict2={}
    CurrentSeasonalDict={}
    print ("Hi2")
    MonthValue=0
    Desc=Description
    for i in range(0,len(InvoiceDate)):            
            Dict2={}
            InvDateList=str(InvoiceDate[i]).split()
            #print (InvDateList)
            if InvDateList[0] not in InvoiceTotal:
                totalProducts=[]
                InvoiceTotal.append(InvDateList[0])
                totalProducts.append(Desc[i])    
            else:
                totalProducts.append(Desc[i])
            
            if "-" in InvDateList[0]:
                #print ("Prsent ")
                InvDateList1=InvDateList[0].split('-')
                if InvDateList1[0] == "2010" or InvDateList1[0] == "2011":
                    MonthValue=int(InvDateList1[2])
                    for key in MonthDict:
                        if key == MonthValue:
                            MonthName=MonthDict[key]        
            for item in set(totalProducts):
                dumy='./slider/TrendingProduct/' + str(item) + '.jpg'
                Dict2[item]=[totalProducts.count(item),dic[item][1],dumy]
            sorted_Count=sorted(Dict2.items(),key=operator.itemgetter(1),reverse=True)
            sortedLength=sorted_Count[:30]
            print(sortedLength)
            Dict1[MonthName]=sortedLength
            
    print(InvoiceDate)
    today=datetime.today()
    CurrentMonthName=MonthDict[today.month]
    print(CurrentMonthName)
    for key in Dict1:
        print(key)
        if key == CurrentMonthName :
            print(Dict1[key])
            CurrentSeasonalDict[CurrentMonthName]=Dict1[key]
   
    return (CurrentSeasonalDict)

def seasonal_product(numberofproducts=10):
    MonthDict={1:"January",2:"February",3:"March",4:"April",5:"May",6:"June",7:"July",8:"August",9:"September",10:"October",11:"November",12:"December"}
    InvoiceTotal=[]
    totalProducts=[]
    Dict1={}
    Dict2={}
    CountryDict={}
    for country in set(Country):
        Dict1={}
        for i in range(0,len(InvoiceDate)):
            if Country[i] == country :
                
                Dict2={}
                InvDateList=str(InvoiceDate[i]).split()
                if InvDateList[0] not in InvoiceTotal:
                    totalProducts=[]
                    InvoiceTotal.append(InvDateList[0])
                    totalProducts.append(Description[i])
                    
                else:
                    totalProducts.append(Description[i])
                if "-" in InvDateList[0]:
                    InvDateList1=InvDateList[0].split('-')
#                    print (InvDateList1)
                    if InvDateList1[0] == "2010" or InvDateList1[0] == "2011":
                        MonthValue=int(InvDateList1[1])
        #                print ("Month Value is : ",MonthValue)
                        for key in MonthDict:
                            if key == MonthValue:
                                MonthName=MonthDict[key]       
                for item in set(totalProducts):
                    Dict2[item]=totalProducts.count(item)
                sorted_Count=sorted(Dict2.items(),key=operator.itemgetter(1),reverse=True)
                sortedLength=sorted_Count[:numberofproducts]
                Dict1[MonthName]=sortedLength
                
                CountryDict[country]=Dict1
    
#    print ("Dictionary country is : ",CountryDict)
    return CountryDict


print("3")



UniqueSCode=list(set(StockCode))
#    UniqueLenSCode=len(list(set(StockCode)))
#Get count of Customers
#    CusUnique=list(set(CustomerID))
userCount=len(set(CustomerID.tolist()))
#create a new dataframe to store Products and AffinityScores
itemAffinity= pd.DataFrame(columns=('Product1', 'Product2', 'score'))
rowCount=0
#For each Product in the list, compare with other Products.
for ind1 in range(len(UniqueSCode)):
    #Get list of customers who bought this Product 1
    Pro1Users = df[df.StockCode==UniqueSCode[ind1]]["CustomerID"].tolist()
    for ind2 in range(ind1, len(UniqueSCode)):
        if ( ind1 == ind2):
            continue
        #Get list of users who bought Product 2
        Pro2Users=df[df.StockCode==UniqueSCode[ind2]]["CustomerID"].tolist()
        commonUsers= len(set(Pro1Users).intersection(set(Pro2Users)))
        score=commonUsers / userCount
        itemAffinity.loc[rowCount] = [UniqueSCode[ind1],UniqueSCode[ind2],score]
        rowCount +=1
itemAffinity.head()  

print("4")


def association1(searchItemName):
    print(searchItemName)
    searchItem=StockCode.tolist()[Description.tolist().index(searchItemName)]
    print(searchItem)
    recoList=itemAffinity[itemAffinity.Product1==searchItem]\
            [["Product2","score"]]\
            .sort_values("score", ascending=[0])
            
    print("Recommendations for Product\n", recoList)
    
    Product2New=recoList['Product2'].tolist()
    scoreNew=recoList['score'].tolist()
    result=[]
    countN=0
    for data in Product2New[:4]:
        dumy='./slider/TrendingProduct/' + str(Description.tolist()[StockCode.tolist().index(data)]) + '.jpg'
        result.append([Description.tolist()[StockCode.tolist().index(data)],scoreNew[countN],dic[Description.tolist()[StockCode.tolist().index(data)]][1],dumy])
        countN+=1
    
    return result
def association2(CustomerID):
    userCount=len(set(CustomerID.tolist()))
    CusUnique=list(set(CustomerID))
    CustomerProduct=pd.DataFrame(columns=("CustomerID","ProductList"))
    c=0
    for CP in range(userCount):
       Products=df[df.CustomerID==CusUnique[CP]]["Description"].tolist()
       CustomerProduct.loc[c]=[CusUnique[CP],Products]
       c+=1
    #starting of using apriori    
    AprioriData=CustomerProduct["ProductList"].tolist()  
    te = TransactionEncoder()
    te_ary = te.fit(AprioriData).transform(AprioriData) 
    dframe = pd.DataFrame(te_ary, columns=te.columns_)
    frequent_itemsets=apriori(dframe, min_support=0.1, use_colnames=True)
    Confidence=association_rules(frequent_itemsets, metric="confidence", min_threshold=0.2)
    return frequent_itemsets

def authenticate(username,password):
    """ insert a new vendor into the vendors table """
    sql = """SELECT username, password
             FROM ce_user where username='16384';"""
    try:        
        params = config()
        conn = psycopg2.connect(**params)
        cur = conn.cursor()
        cur.execute(sql)
        result=cur.fetchall()[0]
        print(result)
        if username==result[0] and password==result[1]:
            returnVal=True
        else:
            returnVal=False
        cur.close()
        return returnVal
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()


###############################################################################
#Configuration
###############################################################################


class Configuration():
    def proxies(self):
        proxy = 'http://proxy-src.research.ge.com:8080'
        os.environ['RSYNC_PROXY'] = "proxy-src.research.ge.com:8080"
        os.environ['http_proxy'] = proxy
        os.environ['HTTP_PROXY'] = proxy
        os.environ['https_proxy'] = proxy
        os.environ['HTTPS_PROXY'] = proxy
        os.environ['no_proxy'] = ".ge.com"

###############################################################################
#Flask Configuration
###############################################################################
            
app = Flask(__name__, static_url_path="", static_folder="static")
CORS(app)
app.secret_key = os.urandom(24)



@app.route('/change/login', methods=['POST'])   
def predict_result():
    try:
        
        #connect()
#        df=pd.read_excel("Book1.xlsx")
#        custid=df['CustomerID']
#        for data in set(custid):
#            insert_vendor(data,data)
        print("Hi")
        input_json_sample = request.get_json(force=True)  
        username=input_json_sample['username']
        password=input_json_sample['password']
        result=authenticate(username,password)
        if result:
            return json.dumps({"result":"Success"})
        else:
            return json.dumps({"result":"Invalid Password"})
    except Exception as err: 
        msg= "Error while login '{}'".format(err)
        return Response(msg, status=500, mimetype='text/plain')
    

@app.route('/change/gettrendingproducts')   
def getTrendingProducts():
    try:
        result=trending_product(CustomerID,Description)
        return json.dumps({"result":result})
    except Exception as err: 
        msg= "No Trending Products Currently'{}'".format(err)
        return Response(msg, status=500, mimetype='text/plain')
    
@app.route('/change/getdemandingproducts')   
def getDemandingProducts():
    try:
        result=demanding_product(Quantity,Description)
        return json.dumps({"result":result})
    except Exception as err: 
        msg= "No Trending Products Currently'{}'".format(err)
        return Response(msg, status=500, mimetype='text/plain')

@app.route('/change/getseasonalproducts')   
def getSeasonalProducts():
    try:
        result=Seasonal()
        return json.dumps({"result":result})
    except Exception as err: 
        msg= "No Trending Products Currently'{}'".format(err)
        return Response(msg, status=500, mimetype='text/plain')

@app.route('/change/getassociation1', methods=['POST'])   
def getAssociation1():
    try:
        input_json_sample = request.get_json(force=True)  
        productName=input_json_sample['productName']
        result=association1(productName)
        return json.dumps({"result":result})
    except Exception as err: 
        msg= "No Trending Products Currently'{}'".format(err)
        return Response(msg, status=500, mimetype='text/plain')
    
@app.route('/change/getassociation2')   
def getAssociation2():
    try:
        result=association2(CustomerID)
        return json.dumps({"result":result})
    except Exception as err: 
        msg= "No Trending Products Currently'{}'".format(err)
        return Response(msg, status=500, mimetype='text/plain')
###############################################################################
#Main
###############################################################################

if __name__ == '__main__':
    configuration = Configuration()
    # Configuring Proxies
    configuration.proxies()
    # Strating Server
    app.run('0.0.0.0',2209)